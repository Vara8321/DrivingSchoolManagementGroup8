import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../Student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-updatepage',
  templateUrl: './updatepage.component.html',
  styleUrls: ['./updatepage.component.css']
})
export class UpdatepageComponent implements OnInit {

  student: Student
  selections: string[]
  options = [
    { name: '2 Wheeler', value: '2 Wheeler', checked: false },
    { name: '4 Wheeler', value: '4 Wheeler', checked: false }
  ]

  constructor(private studentService: StudentService, private router:Router) { }

  ngOnInit(): void {
    this.student = this.studentService.selectedStudent
    console.log(this.student.id)
    console.log(this.student.training_type)
    console.log(this.student.training_type.length)
    if (this.student.training_type.length <= 10) {
      var i = 0
      for (i = 0; i < this.options.length; i++) {
        if (this.student.training_type == this.options[i].name) {
          this.options[i].checked = true;
        }
      }
    }

    else {
      var trainingType = this.student.training_type.split(",")
      var i = 0
      for (i = 0; i < this.options.length; i++) {
        if (trainingType[i] == this.options[i].name) {
          this.options[i].checked = true;
        }
      }
    }

  }

  updateStudent(student:Student) {
    this.selections = this.options.filter(opt => opt.checked).map(opt => opt.value);
    var commaSeperatedTraining = this.selections.toString();
    this.student.training_type = commaSeperatedTraining;
    this.studentService.updateStudent(this.student).subscribe(
      (data)=>{console.log(data);
      }
      );
    this.router.navigateByUrl("adminpage/student")
  }

  goBack()
  {
    this.router.navigateByUrl("adminpage/student")
  }

}
