import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoteformComponent } from './remoteform.component';

describe('RemoteformComponent', () => {
  let component: RemoteformComponent;
  let fixture: ComponentFixture<RemoteformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RemoteformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoteformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
