import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Attendance } from '../Attendance';
import { AttendanceService } from '../attendance.service';

@Component({
  selector: 'app-showattendance',
  templateUrl: './showattendance.component.html',
  styleUrls: ['./showattendance.component.css']
})
export class ShowattendanceComponent implements OnInit {

  constructor(private router:Router, private attendanceService:AttendanceService) { }

  attendance:Attendance[]

  ngOnInit(): void {
    this.attendanceService.fetchAttedance().subscribe(x=>this.attendance=x);
  }

  goToAttendancePage()
  {
    this.router.navigateByUrl("markattendance")
  }

}
