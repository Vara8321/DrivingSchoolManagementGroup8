import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddstudentComponent } from './addstudent/addstudent.component';
import { AddtrainerComponent } from './addtrainer/addtrainer.component';
import { AddvehicleComponent } from './addvehicle/addvehicle.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { ListstudentComponent } from './liststudent/liststudent.component';
import { ListtrainerComponent } from './listtrainer/listtrainer.component';
import { ListvehicleComponent } from './listvehicle/listvehicle.component';
import { LocalstudentscheduleformComponent } from './localstudentscheduleform/localstudentscheduleform.component';
import { MarkattendanceComponent } from './markattendance/markattendance.component';
import { RemoteformComponent } from './remoteform/remoteform.component';
import { RemotestudentscheduleformComponent } from './remotestudentscheduleform/remotestudentscheduleform.component';
import { ShowattendanceComponent } from './showattendance/showattendance.component';
import { ShowscheduleComponent } from './showschedule/showschedule.component';
import { TutorialsComponent } from './tutorials/tutorials.component';
import { UpdatepageComponent } from './updatepage/updatepage.component';
import { UpdatetrainerComponent } from './updatetrainer/updatetrainer.component';
import { UpdatevehicleComponent } from './updatevehicle/updatevehicle.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserpageComponent } from './userpage/userpage.component';
import { StudentregistrationComponent } from './studentregistration/studentregistration.component';

const routes: Routes = [
  {"path":"", component:AdminloginComponent},
  { "path": "adminLogin", component: AdminloginComponent },
  { "path": "userLogin", component: UserloginComponent },
  { "path": "userRegistration", component: StudentregistrationComponent},
  {"path": "adminpage", component: AdminpageComponent,
    children: [{ "path": "student", component: ListstudentComponent },
    { "path": "trainer", component: ListtrainerComponent },
    { "path": "attendance", component: ShowattendanceComponent },
    { "path": "vehicle", component: ListvehicleComponent },
    ]
  },
  {
    "path": "userpage", component: UserpageComponent,
    children: [{ "path": "tutorials", component: TutorialsComponent },
    { "path": "showschedule", component: ShowscheduleComponent },
    { "path": "bookschedule", component: LocalstudentscheduleformComponent }
    ]
  },
  { "path": "admitstudent", component: AddstudentComponent },
  { "path": "updatestudent", component: UpdatepageComponent },
  { "path": "addtrainer", component: AddtrainerComponent },
  { "path": "updatetrainer", component: UpdatetrainerComponent },
  { "path": "markattendance", component: MarkattendanceComponent },
  { "path": "addvehicle", component: AddvehicleComponent },
  { "path": "updatevehicle", component: UpdatevehicleComponent },
  { "path": "localstudentform", component: LocalstudentscheduleformComponent },
  { "path": "remotestudentform", component: RemotestudentscheduleformComponent },
  { "path": "remoteform", component: RemoteformComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
