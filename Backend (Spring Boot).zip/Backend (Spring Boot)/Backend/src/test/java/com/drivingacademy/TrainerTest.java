package com.drivingacademy;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.drivingacademy.entities.Student;
import com.drivingacademy.entities.Trainer;
import com.drivingacademy.repo.TrainerRepository;

@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)

@SpringBootTest
public class TrainerTest {
	@Autowired
	TrainerRepository tRepo;
	
	@Disabled
	@Test
	@Order(1)
	public void trainerCreate() {
		Trainer t=new Trainer();
		t.setLocation("Pune");
		t.setName("Punith");
		tRepo.save(t);
		assertNotNull(tRepo.findAll());
		
	}
	
		@Disabled
		@Test
		@Order(2)
		 public void getTrainerTest(){

	        Trainer t = tRepo.findById(4).get();

	        assertThat(t.getTid()).isEqualTo(4);

	    }

	@Test
	@Order(3)
	public void trainerUpdate() throws Exception {
		  Trainer updateTrainer = tRepo.findById(3).get();
		  updateTrainer.setName("Chetan");
	     
	   tRepo.save(updateTrainer);
	     
	   assertThat(updateTrainer.getName().equals("Chetan"));
	}
	
	@Disabled
	@Test
	@Order(4)
	public void trainerdelete() throws Exception{
	     Trainer t = tRepo.findById(20).get();

	     tRepo.delete(t);

	    Trainer t1 = null;

	     Optional<Trainer> optionalTrainer = tRepo.findById(20);

	     if(optionalTrainer .isPresent()){
	         t1 = optionalTrainer .get();
	     }

	     assertThat(t1).isNull();
	}
	
	}
