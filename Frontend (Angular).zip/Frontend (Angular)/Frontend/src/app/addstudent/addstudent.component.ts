import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../Student';
import { StudentService } from '../student.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-addstudent',
  templateUrl: './addstudent.component.html',
  styleUrls: ['./addstudent.component.css']
})
export class AddstudentComponent implements OnInit {

  constructor(private studentservice:StudentService, private router:Router) { }

  student:Student = new Student()
  selections:string[]
  options = [
    {name:'2 Wheeler', value:'2 Wheeler', checked:false},
    {name:'4 Wheeler', value:'4 Wheeler', checked:false}
  ]

  ngOnInit(): void {
  }

  saveStudent(form: NgForm)
  {
    this.selections = this.options.filter(opt => opt.checked).map(opt => opt.value);
    var commaSeperatedTraining = this.selections.toString();
    this.student.training_type = commaSeperatedTraining;
    console.log(this.student.training_type)
    console.log(this.student.admission_date)
    this.studentservice.addStudent(this.student).subscribe(
      (data)=>{console.log(data);
      }
      );
    this.router.navigateByUrl("adminpage/student")
  }

  goBack()
  {
    this.router.navigateByUrl("adminpage/student")
  }

}
