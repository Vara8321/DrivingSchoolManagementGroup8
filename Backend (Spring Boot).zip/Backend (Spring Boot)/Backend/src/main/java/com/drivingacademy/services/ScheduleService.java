package com.drivingacademy.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.drivingacademy.entities.Schedule;
import com.drivingacademy.repo.ScheduleRepository;

@Service
public class ScheduleService {

	@Autowired
	private ScheduleRepository scheduleRepo;
	
	public List<Schedule> getStudentSchedule(int id)
	{
		List<Schedule> allSchedule = scheduleRepo.findAll();
		List<Schedule> result = new ArrayList<Schedule>();
		for(Schedule schedule:allSchedule)
		{
			if(schedule.getStudent().getId()==id)
			{
				result.add(schedule);
			}
		}
		return result;
	}
	
	public Schedule addSchedule(Schedule sch)
	{
		return scheduleRepo.save(sch);
	}
	
	public void deleteSchedule(int id)
    {
		scheduleRepo.deleteById(id);
    }
}
