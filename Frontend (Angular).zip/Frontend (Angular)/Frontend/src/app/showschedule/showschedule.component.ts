import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Schedule } from '../Schedule';
import { ScheduleService } from '../schedule.service';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-showschedule',
  templateUrl: './showschedule.component.html',
  styleUrls: ['./showschedule.component.css']
})
export class ShowscheduleComponent implements OnInit {

  schedules:Schedule[]
  studentid:number

  constructor(private studentService:StudentService, private router:Router, private scheduleService:ScheduleService) { }

  ngOnInit(): void {
    this.studentid = this.studentService.loggedinStudent.id
    this.scheduleService.getSchedule(this.studentid).subscribe(x=>this.schedules=x);
  }

  loadForm()
  {
    if(this.studentService.loggedinStudent.location=="Pune")
    {
      this.router.navigateByUrl("localstudentform");
    }
    else
    {
      this.router.navigateByUrl("remotestudentform")
    }
  }

  deleteSchedule(id:number)
  {
    this.scheduleService.deleteSchedule(id).subscribe(
      (data)=>{console.log(data);
      });
      this.router.navigateByUrl("userpage")
  }

}
