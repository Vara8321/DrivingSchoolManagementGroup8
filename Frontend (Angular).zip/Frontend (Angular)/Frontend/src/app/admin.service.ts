import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AdminLogin } from './AdminLogin';


@Injectable({
  providedIn: 'root'
})
export class AdminService {
url:string="http://localhost:8969/myapi/admin/"
  constructor(private http:HttpClient) { }

  checkLogin(admin:AdminLogin):any
  {
  return this.http.post(this.url,admin,{ responseType: 'text'})
  }
}
