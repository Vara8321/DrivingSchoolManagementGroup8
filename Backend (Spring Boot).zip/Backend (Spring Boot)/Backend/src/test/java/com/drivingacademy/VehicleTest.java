package com.drivingacademy;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;

import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.drivingacademy.entities.Trainer;
import com.drivingacademy.entities.Vehicle;

import com.drivingacademy.repo.VehicleRepository;
@SpringBootTest
public class VehicleTest {
	@Autowired
	VehicleRepository vRepo;
	
	@Disabled
	@Test
	public void testCreate() {
		Vehicle v=new Vehicle();
		v.setBrand("Honda");
		v.setModel("Jazz");
		v.setType("Four wheel");
		
		vRepo.save(v);
		assertNotNull(vRepo.findAll());
	}
		@Disabled
		@Test
		@Order(2)
		 public void getVehicleTest(){

	       Vehicle v = vRepo.findById(2).get();

	        assertThat(v.getVid()).isEqualTo(2);

	    }

	@Disabled
	@Test
	@Order(3)
	public void vehicleUpdate() throws Exception {
		  Vehicle updateVehicle = vRepo.findById(1).get();
		  updateVehicle.setBrand("Hero");
		  updateVehicle.setModel("Go");
		  updateVehicle.setType("Four wheel");
	   vRepo.save(updateVehicle);
	     
	   assertThat(updateVehicle.getBrand().equals("Hero"));
	   assertThat(updateVehicle.getModel().equals("Go"));
	   assertThat(updateVehicle.getType().equals("Four wheel"));
	}
	
	
	@Test
	@Order(4)
	public void vehicledelete() throws Exception{
	     Vehicle v = vRepo.findById(8).get();

	     vRepo.delete(v);

	  Vehicle v1 = null;

	     Optional<Vehicle> optionalVehicle = vRepo.findById(8);

	     if(optionalVehicle  .isPresent()){
	         v1 = optionalVehicle  .get();
	     }

	     assertThat(v1).isNull();
	}
	
	}