import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Trainer } from '../Trainer';
import { TrainerService } from '../trainer.service';

@Component({
  selector: 'app-remotestudentscheduleform',
  templateUrl: './remotestudentscheduleform.component.html',
  styleUrls: ['./remotestudentscheduleform.component.css']
})
export class RemotestudentscheduleformComponent implements OnInit {

trainers:Trainer[]
visible:boolean = false;

  constructor(private trainerService:TrainerService, private router:Router) { }

  ngOnInit(): void {
  }
  searchValue: string='';
  getValue(val:string)
  {
    console.warn(val);
    this.searchValue = val;
  }

  searchTrainers()
  {
    this.visible=true
    console.log(this.searchValue)
    this.trainerService.getTrainerByLoc(this.searchValue).subscribe(x=>this.trainers=x);
  }

  remoteScheduleBooking(t:Trainer)
  {
    this.trainerService.bookedTrainer = t;
    this.router.navigateByUrl("remoteform")
  }
}
