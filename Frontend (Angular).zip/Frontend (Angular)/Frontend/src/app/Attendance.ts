import { Student } from "./Student";

export class Attendance
{
    aid:number;
    student:Student;
    date:string;
    attendance:string;
}