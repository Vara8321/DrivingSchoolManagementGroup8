import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Schedule } from '../Schedule';
import { ScheduleService } from '../schedule.service';
import { Student } from '../Student';
import { StudentService } from '../student.service';
import { Trainer } from '../Trainer';
import { TrainerService } from '../trainer.service';

@Component({
  selector: 'app-remoteform',
  templateUrl: './remoteform.component.html',
  styleUrls: ['./remoteform.component.css']
})
export class RemoteformComponent implements OnInit {

  trainer:Trainer
  student:Student
  schedule:Schedule = new Schedule()
  constructor(private trainerService:TrainerService, private studentService:StudentService, private scheduleService:ScheduleService, private router:Router) { }

  ngOnInit(): void {
    this.trainer = this.trainerService.bookedTrainer
    this.student = this.studentService.loggedinStudent
  }

  saveSchedule(s:Schedule, t:Trainer)
  {
    s.trainer = t
    s.student = this.student
    this.scheduleService.addSchedule(s).subscribe(
      (data)=>{console.log(data);
      }
      );
    this.router.navigateByUrl("userpage")
  }

  goBack()
  {
    this.router.navigateByUrl("userpage/showschedule")
  }

}
