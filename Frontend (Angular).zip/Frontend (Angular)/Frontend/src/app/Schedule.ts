import { Student } from "./Student"
import { Trainer } from "./Trainer"

export class Schedule
{
    sid:number
    student:Student
    trainer:Trainer
    time:string
    date:string
}