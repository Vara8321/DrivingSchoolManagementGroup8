import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { AdminLogin } from '../AdminLogin';
import { AppComponent } from '../app.component';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

 

  constructor(private router:Router, private appcomp:AppComponent,private adminservice:AdminService, private adminClass:AdminLogin) { }

  ngOnInit(): void {
  }
  email:string=""
  password:string=""
  admin:AdminLogin
  check:string
  message:string

  gotoAdminPage(){
    console.log(this.email)
    console.log(this.password)
    this.admin = new AdminLogin()
    this.admin.name = this.email
    this.admin.password = this.password
   this.adminservice.checkLogin(this.admin).subscribe((res:string) => {
    //response will be parsed as text and we need to convert it to int
    // const resInt = + res;            
    console.log(res)
    if(res=="true")
    {
      this.appcomp.displayLoginNav = false
      this.router.navigate(['/adminpage/student']);
    }
    else{
      this.message = "Error"
    }

    }, )

    
   /* 
    this.appcomp.displayLoginNav=false;*/
  }
}
