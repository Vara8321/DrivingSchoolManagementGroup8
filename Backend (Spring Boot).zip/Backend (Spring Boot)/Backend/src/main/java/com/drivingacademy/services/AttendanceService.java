package com.drivingacademy.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.drivingacademy.entities.Attendance;
import com.drivingacademy.repo.AttendanceRepository;

@Service
public class AttendanceService {

	@Autowired
	private AttendanceRepository attendanceRepo;
	
	public List<Attendance> getAllAttendance()
	{
		return attendanceRepo.findAll();
	}
	
	public List<Attendance> getAllByDate(String date)
	{
		List<Attendance> allAttendance = attendanceRepo.findAll();
		List<Attendance> result = new ArrayList<Attendance>();
		for(Attendance attend: allAttendance)
		{
			if(attend.getDate().equals(date))
			{
				result.add(attend);
			}
		}
		return result;
	}
	
	public Attendance markAttendance(Attendance att)
	{
		return attendanceRepo.save(att);
	}
}
