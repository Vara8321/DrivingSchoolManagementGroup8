import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Vehicle } from '../Vehicle';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-updatevehicle',
  templateUrl: './updatevehicle.component.html',
  styleUrls: ['./updatevehicle.component.css']
})
export class UpdatevehicleComponent implements OnInit {

  vehicle:Vehicle
  
  constructor(private router:Router, private vehicleService:VehicleService) { }

  ngOnInit(): void {
    this.vehicle = this.vehicleService.selectedVehicle
  }

  updateVehicle(v:Vehicle)
  {
    this.vehicleService.updateVehicle(v).subscribe(
      (data)=>{console.log(data);
      }
      );
    this.router.navigateByUrl("adminpage/vehicle")
  }

  goBack()
  {
    this.router.navigateByUrl("adminpage/vehicle")
  }
}
