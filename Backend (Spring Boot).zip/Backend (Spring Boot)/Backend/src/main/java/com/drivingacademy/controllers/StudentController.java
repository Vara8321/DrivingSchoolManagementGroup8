package com.drivingacademy.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.drivingacademy.entities.Admin;
import com.drivingacademy.entities.Student;
import com.drivingacademy.services.StudentService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/myapi/student")
public class StudentController {

	@Autowired
	private StudentService service;
	
	@GetMapping("/fetch")
	public List<Student> fetchStudent() {
		return service.getStudent();
	}
	
	
	@PostMapping("/insert/")
	public ResponseEntity<Student> insertStudent(@RequestBody Student student) {
		Student s = service.saveStudent(student);
		return new ResponseEntity<Student>(s, HttpStatus.CREATED);
	}
	
	
	@PostMapping("/delete")
	public void deleteStudent(@RequestBody int id) {
		service.deleteStudentById(id);
	}
	
	@PostMapping("/update")
	public ResponseEntity<Student> update(@RequestBody Student student) {
		int sid = student.getId();
		Student s = service.updateStudent(sid, student);
		return new ResponseEntity<Student>(s, HttpStatus.OK);
	}
	
	@PostMapping("/")
	public Boolean studentLogin(@RequestBody Student student)
	{
		String name = student.getUsername();
		String password = student.getPassword();
		if(service.verifyStudent(name, password))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
}
