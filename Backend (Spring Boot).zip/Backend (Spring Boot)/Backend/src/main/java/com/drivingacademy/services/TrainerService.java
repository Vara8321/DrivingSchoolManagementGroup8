package com.drivingacademy.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.drivingacademy.entities.Trainer;
import com.drivingacademy.repo.TrainerRepository;

@Service
public class TrainerService {
	
	@Autowired
	private TrainerRepository trainerRepository;
	
	public Trainer addTrainer(Trainer t)
	{
		return trainerRepository.save(t);
	}

	
     public void deleteTrainer(int id)
     {
	     trainerRepository.deleteById(id);
     }

     
     public Trainer updateTrainer(int id, Trainer newT)
     {
    	 Trainer oldT = null;
    	 if(trainerRepository.findById(id).isPresent())
    	 {
    		oldT = trainerRepository.findById(id).get();
    		oldT = newT;
    		trainerRepository.save(oldT);
    	 }
    	 return oldT;
    	 
     }
     public List<Trainer> getAllTrainer()
     {
    	 return trainerRepository.findAll();
     }
     
     public List<Trainer> getTrainerByLocation(String location)
     {
    	 List<Trainer> allTrainers = trainerRepository.findAll();
    	 List<Trainer> result = new ArrayList<Trainer>();
    	 for(Trainer trainer:allTrainers)
    	 {
    		 if(trainer.getLocation().equals(location))
    		 {
    			 result.add(trainer);
    		 }
    	 }
    	 return result;
     }
     
}
