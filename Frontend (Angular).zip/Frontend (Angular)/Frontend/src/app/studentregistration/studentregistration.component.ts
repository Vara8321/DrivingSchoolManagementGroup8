import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';
import { Student } from '../Student';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-studentregistration',
  templateUrl: './studentregistration.component.html',
  styleUrls: ['./studentregistration.component.css']
})
export class StudentregistrationComponent implements OnInit {

  constructor(private studentservice:StudentService, private router:Router) { }

  student:Student = new Student()
  selections:string[]
  options = [
    {name:'2 Wheeler', value:'2 Wheeler', checked:false},
    {name:'4 Wheeler', value:'4 Wheeler', checked:false}
  ]

  ngOnInit(): void {
  }

  saveStudent(form: NgForm)
  {
    this.selections = this.options.filter(opt => opt.checked).map(opt => opt.value);
    var commaSeperatedTraining = this.selections.toString();
    this.student.training_type = commaSeperatedTraining;
    console.log(this.student.training_type)
    console.log(this.student.admission_date)
    this.studentservice.addStudent(this.student).subscribe(
      (data)=>{console.log(data);
      }
      );
    this.router.navigateByUrl("userLogin")
  }

  goBack()
  {
    this.router.navigateByUrl("userLogin")
  }

}
