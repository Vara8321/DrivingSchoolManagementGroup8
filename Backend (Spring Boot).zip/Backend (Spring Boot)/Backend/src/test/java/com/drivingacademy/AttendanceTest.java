package com.drivingacademy;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.ClassOrderer.OrderAnnotation;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.drivingacademy.entities.Attendance;

import com.drivingacademy.repo.AttendanceRepository;


@SpringBootTest
@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)
public class AttendanceTest {
	@Autowired
	AttendanceRepository aRepo;

	@Disabled
	@Test
	@Order(1)
	public void saveAttendanceTest(){

		Attendance a=new Attendance();
		a.setAttendance("Present");
		a.setDate("8/04/2024");
      

        aRepo.save(a);

        assertNotNull(aRepo.findAll());
    }
	
	@Disabled
	@Test
	@Order(2)
	 public void getAttendenceTest(){

        Attendance a = aRepo.findById(3).get();

        assertThat(a.getAid()).isEqualTo(3);

    }

@Disabled
@Test
@Order(3)
public void attendanceUpdate() throws Exception {
	  Attendance updateAttendance = aRepo.findById(2).get();
	  updateAttendance.setAttendance("Absent");
     
   aRepo.save(updateAttendance);
     
   assertThat(updateAttendance.getAttendance().equals("Absent"));
}


@Test
@Order(4)
public void attendancedelete() throws Exception{
     Attendance a = aRepo.findById(4).get();

     aRepo.delete(a);



    Attendance a1 = null;

     Optional<Attendance> optionalAttendance = aRepo.findById(4);

     if( optionalAttendance.isPresent()){
         a1 =  optionalAttendance.get();
     }

     assertThat(a1).isNull();
}
}
