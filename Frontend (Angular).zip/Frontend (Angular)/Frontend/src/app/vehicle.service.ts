import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Vehicle } from './Vehicle';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  selectedVehicle:Vehicle

  addurl:string="http://localhost:8969/myapi/vehicle/add"
  updateurl:string="http://localhost:8969/myapi/vehicle/update"
  fetchurl:string ="http://localhost:8969/myapi/vehicle/"
  deleteurl:string = "http://localhost:8969/myapi/vehicle/delete/"


  constructor(private http:HttpClient) { }

  addvehicle(vehicle:Vehicle){
  
    return this.http.post(this.addurl,vehicle);

  }

  getAllVehicles():Observable<Vehicle[]>
  {
     return this.http.get<Vehicle[]>(this.fetchurl);

  }

  updateVehicle(vehicle:Vehicle){

  
    return this.http.post(this.updateurl,vehicle);


  }

  deleteVehicle(id:number){

 return this.http.post(this.deleteurl,id);

  }


}