package com.drivingacademy.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.drivingacademy.entities.Vehicle;
import com.drivingacademy.repo.VehicleRepository;

@Service
public class VehicleService {

	@Autowired
	private VehicleRepository vehicleRepository;
	
	public Vehicle addVehicle(Vehicle v)
	{
		return vehicleRepository.save(v);
	}
	
	public void deleteVehicle(int id)
	{
		vehicleRepository.deleteById(id);
	}
	
	public Vehicle updateVehile(int id, Vehicle newV)
	{
		Vehicle oldV = null;
		if(vehicleRepository.findById(id).isPresent())
		{
			oldV = vehicleRepository.findById(id).get();
			oldV = newV;
			vehicleRepository.save(oldV);
		}
		return oldV;
	}
	
	public List<Vehicle> getAllVehicles()
	{
		return vehicleRepository.findAll();
	}
}
