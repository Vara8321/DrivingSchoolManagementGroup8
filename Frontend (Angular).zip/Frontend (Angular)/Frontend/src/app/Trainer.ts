import { Vehicle } from "./Vehicle"

export class Trainer
{
    tid:number
    name:string
    location:string
    vehicle:Vehicle
}