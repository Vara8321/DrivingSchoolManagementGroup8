import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListtrainerComponent } from './listtrainer.component';

describe('ListtrainerComponent', () => {
  let component: ListtrainerComponent;
  let fixture: ComponentFixture<ListtrainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListtrainerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListtrainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
