import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Schedule } from './Schedule';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {

  addurl:string = "http://localhost:8969/myapi/schedule/add"
  fetchurl:string = "http://localhost:8969/myapi/schedule/"
  deleteurl:string = "http://localhost:8969/myapi/schedule/delete"

  constructor(private http:HttpClient) { }

  addSchedule(s:Schedule)
  {
    return this.http.post(this.addurl, s)
  }

  getSchedule(id:number):Observable<Schedule[]>
  {
    return this.http.post<Schedule[]>(this.fetchurl,id)
  }

  deleteSchedule(id:number)
  {
    return this.http.post(this.deleteurl,id)
  }
}
