import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Trainer } from './Trainer';

@Injectable({
  providedIn: 'root'
})
export class TrainerService {

  selectedTrainer:Trainer;
  bookedTrainer:Trainer;

  addurl:string = "http://localhost:8969/myapi/trainer/add"
  deleteurl:string = "http://localhost:8969/myapi/trainer/delete"
  updateurl:string = "http://localhost:8969/myapi/trainer/update"
  fetchurl:string = "http://localhost:8969/myapi/trainer/"
  url:string = "http://localhost:8969/myapi/trainer/trainerbyloc"

  constructor(private http:HttpClient) { }

  addTrainer(trainer:Trainer)
  {
    return this.http.post(this.addurl,trainer)
  }

  deleteTrainer(id:number)
  {
    return this.http.post(this.deleteurl,id)
  }

  updateTrainer(trainer:Trainer)
  {
    return this.http.post(this.updateurl,trainer)
  }

  getAllTrainers():Observable<Trainer[]>
  {
    return this.http.get<Trainer[]>(this.fetchurl)
  }

  getTrainerByLoc(location:string):Observable<Trainer[]>
  {
    return this.http.post<Trainer[]>(this.url,location)
  }
}
