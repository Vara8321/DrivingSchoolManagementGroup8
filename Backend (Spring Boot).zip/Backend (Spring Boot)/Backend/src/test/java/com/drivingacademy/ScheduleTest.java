package com.drivingacademy;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.ClassOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.drivingacademy.entities.Schedule;
import com.drivingacademy.entities.Student;
import com.drivingacademy.entities.Trainer;
import com.drivingacademy.repo.ScheduleRepository;
import com.drivingacademy.repo.StudentRepositary;

@SpringBootTest
@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)
public class ScheduleTest {
	@Autowired
	ScheduleRepository sRepo;

@Test
@Order(1)
	public void saveScheduleTest(){

		Schedule s=new Schedule();
        s.getStudent();
        s.setTime("9.30AM");


        sRepo.save(s);

        assertNotNull(sRepo.findAll());
    }

}