package com.drivingacademy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String admission_date;
	private String training_type;
	private String location;
	private int age;
	private String username;
	private String password;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdmission_date() {
		return admission_date;
	}
	public void setAdmission_date(String admission_date) {
		this.admission_date = admission_date;
	}
	public String getTraining_type() {
		return training_type;
	}
	public void setTraining_type(String training_type) {
		this.training_type = training_type;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Student(String name, String admission_date, String training_type, String location, int age, String username,
			String password) {
		super();
		this.name = name;
		this.admission_date = admission_date;
		this.training_type = training_type;
		this.location = location;
		this.age = age;
		this.username = username;
		this.password = password;
	}
	
	public Student() {}
	
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", admission_date=" + admission_date + ", training_type="
				+ training_type + ", location=" + location + ", age=" + age + ", username=" + username + ", password="
				+ password + "]";
	}
		
}
