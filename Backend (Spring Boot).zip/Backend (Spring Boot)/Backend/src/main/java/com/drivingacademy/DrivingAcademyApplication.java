package com.drivingacademy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.drivingacademy")
public class DrivingAcademyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrivingAcademyApplication.class, args);
	}

}
